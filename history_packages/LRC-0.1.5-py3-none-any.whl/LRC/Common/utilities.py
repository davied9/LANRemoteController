import os

def clean_log_dir(dir, filename_regexp):
    pass