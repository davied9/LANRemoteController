# this is create for find package to find this as package,
# so that *.json will be treated as package data